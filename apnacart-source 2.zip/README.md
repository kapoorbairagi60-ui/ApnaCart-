# ApnaCart

Generated with [Appio](https://appio.app)

## Setup

```bash
npm install
npm run dev
```

## Prompt
> Create a shopping app called ApnaCart where customers can browse products, view product details, add products to cart, place orders, and contact the seller on WhatsApp. Include categories like Fashion, Electronics, Grocery and Beauty. Add a seller dashboard where I can add, edit and publish products with price and stock. Make the app simple, modern and mobile-friendly.

## Tech Stack
- React 18 + TypeScript
- Tailwind CSS
- Vite
- Lucide Icons
