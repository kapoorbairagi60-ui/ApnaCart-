var _zdbPfx = "zdb_" + ((typeof window !== "undefined" && window.__APPIO_APP_ID__) ? window.__APPIO_APP_ID__ + "_" : "");
var ZapplyDB = (window.ZapplyDB && typeof window.ZapplyDB.load === "function") ? window.ZapplyDB : {
  save: function(k,d) { try { localStorage.setItem(_zdbPfx+k, JSON.stringify(d)); } catch(e) {} return d; },
  load: function(k,f) { try { var r = localStorage.getItem(_zdbPfx+k); if(r===null||r==="undefined") return f!==undefined?f:null; return JSON.parse(r); } catch(e) { return f!==undefined?f:null; } },
  remove: function(k) { localStorage.removeItem(_zdbPfx+k); },
  addItem: function(k,item) { var l=ZapplyDB.load(k,[]); if(!Array.isArray(l))l=[]; var n={}; for(var p in item){if(item.hasOwnProperty(p))n[p]=item[p];} if(!n.id)n.id=Date.now().toString(36)+"_"+Math.random().toString(36).slice(2,7); l.push(n); ZapplyDB.save(k,l); return l; },
  removeItem: function(k,id) { var l=ZapplyDB.load(k,[]); if(!Array.isArray(l))return[]; var f=l.filter(function(x){return x.id!==id}); ZapplyDB.save(k,f); return f; },
  updateItem: function(k,id,u) { var l=ZapplyDB.load(k,[]); if(!Array.isArray(l))return[]; var m=l.map(function(x){if(x.id!==id)return x; var o={}; for(var p in x){if(x.hasOwnProperty(p))o[p]=x[p];} for(var p2 in u){if(u.hasOwnProperty(p2))o[p2]=u[p2];} return o;}); ZapplyDB.save(k,m); return m; }
};
var useZapplyDB = (window.useZapplyDB && typeof window.useZapplyDB === "function") ? window.useZapplyDB : function(key, initialValue) {
  var stored = ZapplyDB.load(key, initialValue);
  var s = React.useState(stored); var val = s[0]; var setRaw = s[1];
  var setVal = function(nv) { if(typeof nv==="function"){setRaw(function(p){var r=nv(p);ZapplyDB.save(key,r);return r;});}else{ZapplyDB.save(key,nv);setRaw(nv);} };
  return [val, setVal];
};
var generateImageUrl = window.generateImageUrl || function(p, w, h) {
  var seed = 0; for (var i = 0; i < p.length; i++) seed = (seed * 31 + p.charCodeAt(i)) % 100000;
  return "https://picsum.photos/seed/" + Math.abs(seed) + "/" + (w || 400) + "/" + (h || 300);
};
var generateAvatarUrl = window.generateAvatarUrl || function(d) {
  var s = d || "avatar"; var seed = 0; for (var i = 0; i < s.length; i++) seed = (seed * 31 + s.charCodeAt(i)) % 100000;
  return "https://api.dicebear.com/7.x/avataaars/svg?seed=" + Math.abs(seed);
};
var generateHeroUrl = window.generateHeroUrl || function(d, w) {
  return generateImageUrl(d || "abstract background", w || 800, 400);
};

// PALETTE
var theme = {
  bg: "bg-orange-50 dark:bg-gray-950",
  card: "bg-white dark:bg-gray-900 border border-orange-100 dark:border-gray-800 shadow-sm",
  headingText: "text-gray-900 dark:text-white",
  bodyText: "text-gray-700 dark:text-gray-300",
  subtleText: "text-gray-400 dark:text-gray-500",
  accentText: "text-orange-600 dark:text-orange-400",
  cardHeading: "text-gray-900 dark:text-white",
  cardBody: "text-gray-600 dark:text-gray-400",
  cardSubtle: "text-gray-400 dark:text-gray-500",
  cardAccent: "text-orange-600 dark:text-orange-400",
  btn: "bg-orange-600 shadow-md shadow-orange-500/20",
  btnText: "text-white",
  divider: "border-orange-100 dark:border-gray-800",
  input: "w-full px-4 py-3 rounded-xl border border-orange-100 dark:border-gray-800 bg-white dark:bg-gray-900 text-gray-900 dark:text-white placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-orange-500/30 transition-all text-sm"
};

var WA_GREEN = "#25D366";
var CATEGORIES = [
  { name: "Fashion", emoji: "👕" },
  { name: "Electronics", emoji: "📱" },
  { name: "Grocery", emoji: "🥦" },
  { name: "Beauty", emoji: "💄" }
];

var SEED_PRODUCTS = [
  { id: 1, name: "Cotton Kurta Set", category: "Fashion", price: 1299, mrp: 1999, stock: 24, rating: 4.5, sold: 312, published: true, tag: "Bestseller", desc: "Pure cotton straight kurta with palazzo. Breathable, all-day comfort for daily and festive wear.", image: generateImageUrl("indian cotton kurta set folded on wooden table", 400, 300), affiliateLink: "https://example.com/buy/cotton-kurta-set" },
  { id: 2, name: "Running Shoes Pro", category: "Fashion", price: 2499, mrp: 3999, stock: 18, rating: 4.3, sold: 188, published: true, tag: "New", desc: "Lightweight mesh upper with cushioned sole. Built for daily runs and gym sessions.", image: generateImageUrl("red running shoes on white floor studio", 400, 300), affiliateLink: "https://example.com/buy/running-shoes-pro" },
  { id: 3, name: "Denim Jacket Classic", category: "Fashion", price: 1899, mrp: 2999, stock: 12, rating: 4.6, sold: 96, published: true, tag: "", desc: "Mid-wash denim jacket with brass buttons and relaxed fit. Layers well in every season.", image: generateImageUrl("blue denim jacket on wooden hanger", 400, 300), affiliateLink: "https://example.com/buy/denim-jacket-classic" },
  { id: 4, name: "Wireless Earbuds Air", category: "Electronics", price: 1799, mrp: 2999, stock: 31, rating: 4.4, sold: 540, published: true, tag: "Deal", desc: "40 hour battery, ENC calling and low latency gaming mode. Comes with Type-C fast charge.", image: generateImageUrl("white wireless earbuds case on desk", 400, 300), affiliateLink: "https://example.com/buy/wireless-earbuds-air" },
  { id: 5, name: "Smart Watch Fit 2", category: "Electronics", price: 2999, mrp: 4999, stock: 9, rating: 4.2, sold: 274, published: true, tag: "", desc: "1.85 inch AMOLED display, SpO2, heart rate and 100+ sports modes. 7 day battery life.", image: generateImageUrl("black smartwatch with fitness dial on table", 400, 300), affiliateLink: "https://example.com/buy/smart-watch-fit-2" },
  { id: 6, name: "Smart LED Bulb 9W", category: "Electronics", price: 499, mrp: 899, stock: 64, rating: 4.1, sold: 733, published: true, tag: "Value", desc: "16 million colours, app + voice control, works with Alexa and Google Home. Set timers easily.", image: generateImageUrl("colorful smart led bulb glowing in lamp", 400, 300), affiliateLink: "https://example.com/buy/smart-led-bulb-9w" },
  { id: 7, name: "Basmati Rice 5kg", category: "Grocery", price: 649, mrp: 850, stock: 40, rating: 4.7, sold: 612, published: true, tag: "Bestseller", desc: "Aged long grain basmati rice. Extra fluffy biryani and pulao with a rich natural aroma.", image: generateImageUrl("basmati rice grains in open jute sack", 400, 300), affiliateLink: "https://example.com/buy/basmati-rice-5kg" },
  { id: 8, name: "Cold Pressed Olive Oil 1L", category: "Grocery", price: 899, mrp: 1199, stock: 22, rating: 4.5, sold: 143, published: true, tag: "", desc: "Extra virgin, single origin, unrefined. Perfect for salads, sautéing and daily cooking.", image: generateImageUrl("olive oil glass bottle with olives on counter", 400, 300), affiliateLink: "https://example.com/buy/olive-oil-1l" },
  { id: 9, name: "Organic Almonds 500g", category: "Grocery", price: 729, mrp: 999, stock: 7, rating: 4.6, sold: 305, published: true, tag: "Low stock", desc: "Hand-picked California almonds. Crunchy, protein rich and ideal for soaking overnight.", image: generateImageUrl("almonds in wooden bowl close up", 400, 300), affiliateLink: "https://example.com/buy/organic-almonds-500g" },
  { id: 10, name: "Vitamin C Face Serum", category: "Beauty", price: 549, mrp: 899, stock: 35, rating: 4.4, sold: 421, published: true, tag: "Trending", desc: "10% Vitamin C with hyaluronic acid. Fades dark spots and gives a visible glow in 4 weeks.", image: generateImageUrl("serum dropper bottle with orange slice", 400, 300), affiliateLink: "https://example.com/buy/vitamin-c-face-serum" },
  { id: 11, name: "Matte Lipstick Trio", category: "Beauty", price: 749, mrp: 1199, stock: 26, rating: 4.3, sold: 267, published: true, tag: "", desc: "Transfer proof matte lipsticks in nude, brick and rose. Enriched with shea butter.", image: generateImageUrl("three matte lipstick tubes on pink surface", 400, 300), affiliateLink: "https://example.com/buy/matte-lipstick-trio" },
  { id: 12, name: "Sunscreen SPF 50 PA+++", category: "Beauty", price: 449, mrp: 649, stock: 0, rating: 4.8, sold: 689, published: false, tag: "Sold out", desc: "No white cast, gel cream texture. Broad spectrum protection for Indian summer.", image: generateImageUrl("sunscreen tube with sunglasses on beach towel", 400, 300), affiliateLink: "https://example.com/buy/sunscreen-spf-50" }
];

var SEED_ORDERS = [
  { id: "AC10241", date: "2026-03-14", status: "Delivered", total: 2398, items: "Cotton Kurta Set x1, Vitamin C Face Serum x2" },
  { id: "AC10239", date: "2026-03-11", status: "Out for delivery", total: 1799, items: "Wireless Earbuds Air x1" },
  { id: "AC10234", date: "2026-03-07", status: "Shipped", total: 1378, items: "Basmati Rice 5kg x1, Almonds 500g x1" },
  { id: "AC10228", date: "2026-03-02", status: "Delivered", total: 499, items: "Smart LED Bulb 9W x1" },
  { id: "AC10219", date: "2026-02-25", status: "Cancelled", total: 749, items: "Matte Lipstick Trio x1" }
];

function buildWaLink(number, text) {
  return "https://wa.me/" + number + "?text=" + encodeURIComponent(text);
}

function cn() {
  var args = Array.prototype.slice.call(arguments);
  return args.filter(Boolean).join(' ');
}

function StarRating(props) {
  var rating = props.rating || 0;
  var size = props.size || 14;
  var stars = [];
  for (var i = 0; i < 5; i++) {
    stars.push(React.createElement(Star, { key: i, size: size, className: i < Math.floor(rating) ? "text-amber-500 fill-amber-500" : "text-gray-300" }));
  }
  return React.createElement('div', { className: 'flex' }, stars);
}

function MiniBarChart(props) {
  var values = props.values || [];
  var color = props.color || "bg-orange-500";
  var height = props.height || 60;
  var max = Math.max.apply(Math, values.concat([1]));
  return React.createElement('div', { className: 'flex items-end gap-1', style: { height: height + 'px' } },
    values.map(function(v, i) {
      return React.createElement('div', { key: i, className: cn('flex-1 rounded-t', color), style: { height: (v / max * height) + 'px' } });
    })
  );
}

function Badge(props) {
  return React.createElement('span', { className: cn("px-2 py-0.5 rounded-full text-[10px] font-bold border border-orange-200 dark:border-gray-700", props.className) }, props.children);
}

var toast = function toast(opts) {
  alert((opts.title || '') + '\n' + (opts.description || ''));
};

function CountUp(props) {
  var cs = React.useState(0);
  var count = cs[0];
  var setCount = cs[1];
  React.useEffect(function() {
    var target = props.to || 0;
    var start = Date.now();
    var dur = 900;
    var id = setInterval(function() {
      var elapsed = Date.now() - start;
      if (elapsed >= dur) { setCount(target); clearInterval(id); return; }
      setCount(Math.round(target * (elapsed / dur)));
    }, 16);
    return function() { clearInterval(id); };
  }, [props.to]);
  return React.createElement('span', { className: props.className }, (props.prefix || '') + count.toLocaleString() + (props.suffix || ''));
}

function SectionLabel(props) {
  return React.createElement('div', { className: "text-[10px] font-bold uppercase tracking-[0.12em] mb-2 text-gray-400 dark:text-gray-500" }, props.children);
}

function SplashScreen(props) {
  React.useEffect(function() { setTimeout(props.onFinish, 1800); }, []);
  return React.createElement(React.Fragment, null,
    React.createElement('div', { className: "min-h-screen flex items-center justify-center bg-orange-50 dark:bg-gray-950" },
      React.createElement('div', { className: "text-center animate-fade-in" },
        React.createElement('div', { className: "w-20 h-20 rounded-3xl bg-orange-600 shadow-md shadow-orange-500/20 flex items-center justify-center mx-auto mb-4" },
          React.createElement(ShoppingBag, { size: 38, className: "text-white" })
        ),
        React.createElement('h1', { className: "text-3xl font-black tracking-tight text-gray-900 dark:text-white" }, "ApnaCart"),
        React.createElement('p', { className: "text-sm text-gray-400 dark:text-gray-500 mt-2" }, "Apna bazaar, apne ghar par")
      )
    )
  );
}

function ProductCard(props) {
  var p = props.product;
  var i = props.index || 0;
  var off = p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0;
  return React.createElement(React.Fragment, null,
    React.createElement('div', { className: theme.card + " rounded-2xl overflow-hidden hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200 animate-fade-in-up", style: { animationDelay: (i * 80) + "ms" } },
      React.createElement('div', { className: "relative cursor-pointer", onClick: function() { props.onOpen(p); } },
        React.createElement('img', { src: p.image, alt: p.name, className: "w-full h-28 object-cover" }),
        off > 0 ? React.createElement('span', { className: "absolute top-2 left-2 bg-orange-600 shadow-md shadow-orange-500/20 text-white text-[10px] font-bold px-2 py-0.5 rounded-full" }, off + "% OFF") : null,
        p.stock === 0 ? React.createElement('div', { className: "absolute inset-0 bg-black/45 flex items-center justify-center" },
          React.createElement('span', { className: "text-[11px] font-bold text-white uppercase tracking-wider" }, "Sold out")
        ) : null
      ),
      React.createElement('div', { className: "p-3" },
        React.createElement('p', { className: "text-sm font-semibold truncate " + theme.cardHeading }, p.name),
        React.createElement('div', { className: "flex items-center gap-1 mt-1" },
          React.createElement(Star, { size: 11, className: "text-amber-500 fill-amber-500" }),
          React.createElement('span', { className: "text-[11px] font-semibold text-gray-600 dark:text-gray-400" }, p.rating),
          React.createElement('span', { className: "text-[10px] text-gray-400 dark:text-gray-500" }, "· " + p.sold + " sold")
        ),
        React.createElement('div', { className: "flex items-end justify-between mt-2" },
          React.createElement('div', null,
            React.createElement('p', { className: "text-sm font-black text-gray-900 dark:text-white" }, "₹" + p.price),
            off > 0 ? React.createElement('p', { className: "text-[10px] line-through text-gray-400 dark:text-gray-500" }, "₹" + p.mrp) : null
          ),
          React.createElement('button', { onClick: function() { props.onAdd(p); }, disabled: p.stock === 0, className: p.stock === 0 ? "w-8 h-8 rounded-lg bg-gray-200 dark:bg-gray-800 flex items-center justify-center text-gray-400" : "w-8 h-8 rounded-lg bg-orange-600 shadow-md shadow-orange-500/20 text-white flex items-center justify-center active:scale-90 transition-all" },
            React.createElement(Plus, { size: 15 })
          )
        ),
        React.createElement('a', { href: p.affiliateLink || "#", target: "_blank", rel: "noreferrer",
          className: cn("mt-3 w-full rounded-lg py-2 text-xs font-semibold flex items-center justify-center gap-1 transition-all",
            p.affiliateLink ? theme.btn + " " + theme.btnText : "bg-gray-200 dark:bg-gray-800 text-gray-400 cursor-not-allowed"),
          onClick: function(e) { if (!p.affiliateLink) e.preventDefault(); }
        },
          React.createElement(Zap, { size: 12 }), " Buy Now"
        )
      )
    )
  );
}

function HomePage(props) {
  var products = props.products || [];
  var live = products.filter(function(p) { return p.published; });
  var trending = live.slice(0, 6);
  var deals = live.filter(function(p) { return p.mrp > p.price; }).slice(0, 5);
  var topRated = live.slice().sort(function(a, b) { return b.rating - a.rating; }).slice(0, 5);
  return React.createElement(React.Fragment, null,
    React.createElement('div', { className: "min-h-screen" },
      React.createElement('div', { className: "px-5 pt-6 pb-24" },
        React.createElement('div', { className: "rounded-3xl bg-gradient-to-br from-orange-500 to-rose-500 p-5 shadow-lg shadow-orange-500/25 animate-fade-in" },
          React.createElement('div', { className: "flex items-center justify-between" },
            React.createElement('div', null,
              React.createElement('p', { className: "text-[11px] font-semibold uppercase tracking-[0.12em] text-white/80" }, "Deliver to 560034"),
              React.createElement('h1', { className: "text-2xl font-black tracking-tight text-white mt-1" }, "Hi Aarav 👋")
            ),
            React.createElement('button', { onClick: function() { props.setPage("seller"); }, className: "w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center active:scale-90 transition-all" },
              React.createElement(Wallet, { size: 18, className: "text-white" })
            )
          ),
          React.createElement('button', { onClick: function() { props.setPage("search"); }, className: "w-full mt-4 bg-white rounded-xl px-4 py-3 flex items-center gap-2 text-left active:scale-[0.99] transition-all" },
            React.createElement(Search, { size: 16, className: "text-gray-400" }),
            React.createElement('span', { className: "text-sm text-gray-400" }, "Search kurta, earbuds, rice...")
          ),
          React.createElement('div', { className: "grid grid-cols-3 mt-4" },
            React.createElement('div', { className: "flex flex-col  border-r border-white/25" },
              React.createElement('span', { className: "text-xl font-black text-white" }, React.createElement(CountUp, { to: live.length })),
              React.createElement('span', { className: "text-[10px] font-semibold uppercase tracking-wider text-white/80" }, "Products")
            ),
            React.createElement('div', { className: "flex flex-col  border-r border-white/25" },
              React.createElement('span', { className: "text-xl font-black text-white" }, React.createElement(CountUp, { to: 1499 })),
              React.createElement('span', { className: "text-[10px] font-semibold uppercase tracking-wider text-white/80" }, "Happy Buyers")
            ),
            React.createElement('div', { className: "flex flex-col " },
              React.createElement('span', { className: "text-xl font-black text-white" }, "4.6 ★"),
              React.createElement('span', { className: "text-[10px] font-semibold uppercase tracking-wider text-white/80" }, "Rating")
            )
          )
        ),

        React.createElement('div', { className: "mt-6" },
          React.createElement(SectionLabel, null, "Shop by category"),
          React.createElement('div', { className: "grid grid-cols-4 gap-2" },
            CATEGORIES.map(function(c, i) {
              return React.createElement('button', { key: c.name, onClick: function() { props.setCategory(c.name); props.setPage("search"); }, className: theme.card + " rounded-2xl py-3 flex flex-col  gap-1 hover:shadow-lg active:scale-95 transition-all animate-fade-in-up", style: { animationDelay: (i * 70) + "ms" } },
                React.createElement('span', { className: "text-xl" }, c.emoji),
                React.createElement('span', { className: "text-[10px] font-semibold text-gray-700 dark:text-gray-300" }, c.name)
              );
            })
          )
        ),

        React.createElement('div', { className: "mt-6" },
          React.createElement('div', { className: "flex items-center justify-between mb-2" },
            React.createElement(SectionLabel, null, "Deals of the day"),
            React.createElement('span', { className: "text-[11px] font-semibold text-orange-600 dark:text-orange-400 mb-2" }, "Ends in 04:12:33")
          ),
          React.createElement('div', { className: "flex gap-3 overflow-x-auto pb-2 -mx-5 px-5" },
            deals.map(function(p, i) {
              return React.createElement('div', { key: p.id, onClick: function() { props.onOpen(p); }, className: theme.card + " rounded-2xl overflow-hidden shrink-0 w-40 animate-fade-in-up", style: { animationDelay: (i * 80) + "ms" } },
                React.createElement('img', { src: p.image, alt: p.name, className: "w-full h-24 object-cover" }),
                React.createElement('div', { className: "p-3" },
                  React.createElement('p', { className: "text-xs font-semibold truncate text-gray-900 dark:text-white" }, p.name),
                  React.createElement('p', { className: "text-sm font-black text-orange-600 dark:text-orange-400 mt-1" }, "₹" + p.price)
                )
              );
            })
          )
        ),

        React.createElement('div', { className: "mt-4" },
          React.createElement('div', { className: "flex items-center justify-between mb-2" },
            React.createElement(SectionLabel, null, "Trending now"),
            React.createElement('button', { onClick: function() { props.setCategory("All"); props.setPage("search"); }, className: "text-[11px] font-semibold text-orange-600 dark:text-orange-400 mb-2" }, "View all")
          ),
          React.createElement('div', { className: "grid grid-cols-2 gap-3" },
            trending.map(function(p, i) {
              return React.createElement(ProductCard, { key: p.id, product: p, index: i, onAdd: props.onAdd, onOpen: props.onOpen });
            })
          )
        ),

        React.createElement('div', { className: "mt-6" },
          React.createElement(SectionLabel, null, "Top rated this week"),
          React.createElement('div', { className: "space-y-2" },
            topRated.map(function(p, i) {
              return React.createElement('div', { key: p.id, className: theme.card + " rounded-2xl p-3 flex items-center gap-3 w-full animate-fade-in-up", style: { animationDelay: (i * 70) + "ms" } },
                React.createElement('img', { src: p.image, alt: p.name, className: "w-14 h-14 rounded-xl object-cover shrink-0" }),
                React.createElement('div', { className: "flex-1 min-w-0" },
                  React.createElement('p', { className: "text-sm font-bold truncate " + theme.cardHeading }, p.name),
                  React.createElement('p', { className: "text-[11px] truncate " + theme.cardSubtle }, p.category + " · " + p.stock + " in stock"),
                  React.createElement('div', { className: "flex items-center gap-1 mt-0.5" },
                    React.createElement(Star, { size: 10, className: "text-amber-500 fill-amber-500" }),
                    React.createElement('span', { className: "text-[11px] font-semibold text-gray-600 dark:text-gray-400" }, p.rating)
                  )
                ),
                React.createElement('div', { className: "text-right shrink-0" },
                  React.createElement('p', { className: "text-sm font-black " + theme.cardAccent }, "₹" + p.price),
                  React.createElement('button', { onClick: function() { props.onOpen(p); }, className: "text-[11px] font-semibold text-orange-600 dark:text-orange-400 mt-1" }, "View")
                )
              );
            })
          )
        )
      )
    )
  );
}

function SearchPage(props) {
  var qs = React.useState("");
  var query = qs[0];
  var setQuery = qs[1];
  var active = props.category || "All";
  var products = (props.products || []).filter(function(p) { return p.published; });
  var list = products.filter(function(p) {
    var okCat = active === "All" || p.category === active;
    var okQ = p.name.toLowerCase().indexOf(query.toLowerCase()) >= 0 || p.category.toLowerCase().indexOf(query.toLowerCase()) >= 0;
    return okCat && okQ;
  });
  var filters = ["All", "Fashion", "Electronics", "Grocery", "Beauty"];
  return React.createElement(React.Fragment, null,
    React.createElement('div', { className: "min-h-screen" },
      React.createElement('div', { className: "px-5 pt-6 pb-24" },
        React.createElement('h2', { className: "text-2xl font-bold tracking-tight bg-gradient-to-r from-orange-500 to-purple-400 bg-clip-text text-transparent mb-3" }, "Browse"),
        React.createElement('div', { className: "relative mb-4" },
          React.createElement(Search, { size: 18, className: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500" }),
          React.createElement('input', { value: query, onChange: function(e) { setQuery(e.target.value); }, placeholder: "Search products...", className: theme.input + " pl-10" })
        ),
        React.createElement('div', { className: "flex gap-2 mb-4 overflow-x-auto pb-1" },
          filters.map(function(cat) {
            return React.createElement('button', { key: cat, onClick: function() { props.setCategory(cat); }, className: "px-4 py-2 rounded-full text-xs font-medium whitespace-nowrap transition-all " + (active === cat ? theme.btn + " " + theme.btnText : theme.card + " text-gray-700 dark:text-gray-300") }, cat);
          })
        ),
        React.createElement('div', { className: "flex items-center justify-between mb-3" },
          React.createElement(SectionLabel, null, list.length + " products found"),
          React.createElement(Filter, { size: 14, className: "text-gray-400 dark:text-gray-500 mb-2" })
        ),
        list.length === 0 ? (
          React.createElement('div', { className: "text-center py-16 px-6" },
            React.createElement('div', { className: "text-6xl mb-4" }, "🔍"),
            React.createElement('h3', { className: "text-lg font-bold mb-2 text-gray-900 dark:text-white" }, "No products found"),
            React.createElement('p', { className: "text-sm mb-6 text-gray-400 dark:text-gray-500" }, "Try a different keyword or category."),
            React.createElement('button', { onClick: function() { setQuery(""); props.setCategory("All"); }, className: theme.btn + " " + theme.btnText + " px-6 py-3 rounded-xl font-semibold active:scale-95 transition-all" }, "Clear filters")
          )
        ) : (
          React.createElement('div', { className: "grid grid-cols-2 gap-3" },
            list.map(function(p, i) { return React.createElement(ProductCard, { key: p.id, product: p, index: i, onAdd: props.onAdd, onOpen: props.onOpen }); })
          )
        )
      )
    )
  );
}

function DetailPage(props) {
  var p = props.product;
  if (!p) { return React.createElement('div', { className: "min-h-screen" }); }
  var qs = React.useState(1);
  var qty = qs[0];
  var setQty = qs[1];
  var off = p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0;
  var similar = (props.products || []).filter(function(x) { return x.category === p.category && x.id !== p.id && x.published; }).slice(0, 4);
  var msg = "Hi ApnaCart! I am interested in " + p.name + " (" + p.category + ") priced at Rs " + p.price + ". Quantity: " + qty + ". Is it available?";
  return React.createElement(React.Fragment, null,
    React.createElement('div', { className: "min-h-screen" },
      React.createElement('div', { className: "px-5 pt-4 pb-28" },
        React.createElement('button', { onClick: function() { props.setPage("home"); }, className: "flex items-center gap-1 text-sm font-semibold text-orange-600 dark:text-orange-400 mb-3 active:scale-95 transition-all" },
          React.createElement(ArrowLeft, { size: 16 }), " Back to shop"
        ),
        React.createElement('img', { src: p.image, alt: p.name, className: "w-full h-56 object-cover rounded-3xl" }),
        React.createElement('div', { className: theme.card + " rounded-3xl p-5 -mt-6 relative" },
          React.createElement('div', { className: "flex items-start justify-between gap-3" },
            React.createElement('div', null,
              React.createElement('h2', { className: "text-lg font-semibold " + theme.cardHeading }, p.name),
              React.createElement('p', { className: theme.cardSubtle + " text-[11px] mt-0.5" }, p.category + " · " + p.sold + " sold")
            ),
            p.tag ? React.createElement(Badge, { className: "bg-orange-500/15 text-orange-600 dark:text-orange-400 border-0 text-[10px] font-bold" }, p.tag) : null
          ),
          React.createElement('div', { className: "flex items-center gap-2 mt-3" },
            React.createElement(StarRating, { rating: p.rating, size: 14 }),
            React.createElement('span', { className: "text-[11px] font-semibold text-gray-600 dark:text-gray-400" }, p.rating + " out of 5")
          ),
          React.createElement('div', { className: "flex items-end gap-2 mt-4" },
            React.createElement('span', { className: "text-3xl font-black tracking-tight text-gray-900 dark:text-white" }, "₹" + p.price),
            off > 0 ? React.createElement('span', { className: "text-sm line-through text-gray-400 dark:text-gray-500 mb-1" }, "₹" + p.mrp) : null,
            off > 0 ? React.createElement('span', { className: "text-sm font-bold text-emerald-600 dark:text-emerald-400 mb-1" }, off + "% off") : null
          ),
          React.createElement('a', { href: p.affiliateLink || "#", target: "_blank", rel: "noreferrer",
            className: cn("mt-4 w-full rounded-xl py-3.5 font-semibold flex items-center justify-center gap-2 transition-all",
              p.affiliateLink ? theme.btn + " " + theme.btnText + " shadow-lg" : "bg-gray-300 dark:bg-gray-800 text-gray-500 cursor-not-allowed"),
            onClick: function(e) { if (!p.affiliateLink) e.preventDefault(); }
          },
            React.createElement(Zap, { size: 16 }), " Buy Now"
          ),
          React.createElement('p', { className: theme.cardBody + " text-sm mt-3 leading-relaxed" }, p.desc),
          React.createElement('div', { className: "flex items-center justify-between mt-4 pt-4 border-t border-orange-100 dark:border-gray-800" },
            React.createElement('div', { className: "flex items-center gap-3" },
              React.createElement('button', { onClick: function() { setQty(Math.max(1, qty - 1)); }, className: "w-8 h-8 rounded-lg bg-orange-500/15 flex items-center justify-center text-orange-600 dark:text-orange-400 active:scale-90 transition-all" },
                React.createElement(Minus, { size: 15 })
              ),
              React.createElement('span', { className: "text-base font-bold text-gray-900 dark:text-white" }, qty),
              React.createElement('button', { onClick: function() { setQty(qty + 1); }, className: "w-8 h-8 rounded-lg bg-orange-500/15 flex items-center justify-center text-orange-600 dark:text-orange-400 active:scale-90 transition-all" },
                React.createElement(Plus, { size: 15 })
              )
            ),
            React.createElement('span', { className: p.stock > 0 ? "text-[11px] font-semibold text-emerald-600 dark:text-emerald-400" : "text-[11px] font-semibold text-red-600 dark:text-red-400" },
              p.stock > 0 ? "In stock · " + p.stock + " left" : "Out of stock"
            )
          )
        ),

        React.createElement('div', { className: "grid grid-cols-2 gap-3 mt-4" },
          React.createElement('button', { disabled: p.stock === 0, onClick: function() { props.onAddQty(p, qty); }, className: (p.stock === 0 ? "bg-gray-300 dark:bg-gray-800 text-gray-500 " : theme.btn + " " + theme.btnText + " shadow-lg ") + "rounded-xl py-3.5 font-semibold flex items-center justify-center gap-2 active:scale-95 transition-all" },
            React.createElement(ShoppingCart, { size: 16 }), " Add to cart"
          ),
          React.createElement('a', { href: buildWaLink(props.waNumber, msg), target: "_blank", rel: "noreferrer", className: "rounded-xl py-3.5 font-semibold flex items-center justify-center gap-2 text-white active:scale-95 transition-all", style: { backgroundColor: WA_GREEN } },
            React.createElement(MessageCircle, { size: 16 }), " Ask seller"
          )
        ),

        React.createElement('div', { className: theme.card + " rounded-3xl p-5 mt-5" },
          React.createElement(SectionLabel, null, "Why order from ApnaCart"),
          [ { icon: React.createElement(Package, { size: 16 }), t: "Free delivery above ₹999", s: "Delivered in 2-4 days" },
            { icon: React.createElement(Shield, { size: 16 }), t: "7 day easy return", s: "No questions asked policy" },
            { icon: React.createElement(CreditCard, { size: 16 }), t: "Cash on delivery", s: "UPI and cards also accepted" }
          ].map(function(r, i) {
            return React.createElement('div', { key: i, className: "flex items-center gap-3 py-2 w-full" },
              React.createElement('div', { className: "w-9 h-9 rounded-xl bg-orange-500/15 flex items-center justify-center text-orange-600 dark:text-orange-400 shrink-0" }, r.icon),
              React.createElement('div', { className: "flex-1 min-w-0" },
                React.createElement('p', { className: "text-sm font-semibold text-gray-900 dark:text-white" }, r.t),
                React.createElement('p', { className: "text-[11px] text-gray-400 dark:text-gray-500" }, r.s)
              )
            );
          })
        ),

        similar.length > 0 ? (
          React.createElement('div', { className: "mt-6" },
            React.createElement(SectionLabel, null, "You may also like"),
            React.createElement('div', { className: "grid grid-cols-2 gap-3" },
              similar.map(function(s, i) { return React.createElement(ProductCard, { key: s.id, product: s, index: i, onAdd: props.onAdd, onOpen: props.onOpen }); })
            )
          )
        ) : null
      )
    )
  );
}

function CartPage(props) {
  var cart = props.cart || [];
  var products = props.products || [];
  var rows = cart.map(function(c) {
    var p = products.find(function(x) { return x.id === c.id; });
    return { id: c.id, qty: c.qty, product: p };
  }).filter(function(r) { return r.product; });
  var subtotal = rows.reduce(function(s, r) { return s + (r.product.price * r.qty); }, 0);
  var delivery = subtotal > 999 || subtotal === 0 ? 0 : 49;
  var total = subtotal + delivery;
  var orderText = "Hi ApnaCart! I would like to order: " + rows.map(function(r) { return r.qty + "x " + r.product.name + " (Rs " + r.product.price + ")"; }).join(" | ") + " | Subtotal: Rs " + subtotal + " | Delivery: Rs " + delivery + " | Total: Rs " + total + " | Name: Aarav Mehta, 560034, Bengaluru";
  if (rows.length === 0) {
    return React.createElement(React.Fragment, null,
      React.createElement('div', { className: "min-h-screen" },
        React.createElement('div', { className: "px-5 pt-6 pb-24" },
          React.createElement('h2', { className: "text-2xl font-bold tracking-tight bg-gradient-to-r from-orange-500 to-purple-400 bg-clip-text text-transparent mb-4" }, "Your Cart"),
          React.createElement('div', { className: "text-center py-16 px-6" },
            React.createElement('div', { className: "text-6xl mb-4" }, "🛒"),
            React.createElement('h3', { className: "text-lg font-bold mb-2 text-gray-900 dark:text-white" }, "Your cart is empty"),
            React.createElement('p', { className: "text-sm mb-6 text-gray-400 dark:text-gray-500" }, "Add your first product and checkout on WhatsApp in seconds."),
            React.createElement('button', { onClick: function() { props.setPage("home"); }, className: theme.btn + " " + theme.btnText + " px-6 py-3 rounded-xl font-semibold active:scale-95 transition-all" }, "Start shopping")
          )
        )
      )
    );
  }
  return React.createElement(React.Fragment, null,
    React.createElement('div', { className: "min-h-screen" },
      React.createElement('div', { className: "px-5 pt-6 pb-28" },
        React.createElement('h2', { className: "text-2xl font-bold tracking-tight bg-gradient-to-r from-orange-500 to-purple-400 bg-clip-text text-transparent mb-4" }, "Your Cart"),
        React.createElement(SectionLabel, null, "Deliver to"),
        React.createElement('div', { className: theme.card + " rounded-2xl p-4 flex items-center gap-3 mb-5" },
          React.createElement('div', { className: "w-10 h-10 rounded-xl bg-orange-500/15 flex items-center justify-center shrink-0" },
            React.createElement(MapPin, { size: 18, className: "text-orange-600 dark:text-orange-400" })
          ),
          React.createElement('div', { className: "flex-1 min-w-0" },
            React.createElement('p', { className: "text-sm font-bold text-gray-900 dark:text-white" }, "Aarav Mehta · Home"),
            React.createElement('p', { className: "text-[11px] text-gray-400 dark:text-gray-500 truncate" }, "402, Green Residency, Koramangala, Bengaluru 560034")
          ),
          React.createElement('button', { onClick: function() { toast({ title: "Address", description: "Address editing opened" }); }, className: "text-[11px] font-semibold text-orange-600 dark:text-orange-400 shrink-0" }, "Change")
        ),

        React.createElement(SectionLabel, null, rows.length + " items in cart"),
        React.createElement('div', { className: "space-y-2 mb-5" },
          rows.map(function(r, i) {
            return React.createElement('div', { key: r.id, className: theme.card + " rounded-2xl p-3 flex items-center gap-3 w-full animate-fade-in-up", style: { animationDelay: (i * 70) + "ms" } },
              React.createElement('img', { src: r.product.image, alt: r.product.name, className: "w-14 h-14 rounded-xl object-cover shrink-0" }),
              React.createElement('div', { className: "flex-1 min-w-0" },
                React.createElement('p', { className: "text-sm font-bold truncate " + theme.cardHeading }, r.product.name),
                React.createElement('p', { className: "text-[11px] truncate " + theme.cardSubtle }, r.product.category),
                React.createElement('p', { className: "text-sm font-black mt-0.5 " + theme.cardAccent }, "₹" + r.product.price * r.qty)
              ),
              React.createElement('div', { className: "flex flex-col items-end gap-2 shrink-0" },
                React.createElement('button', { onClick: function() { props.removeFromCart(r.id); }, className: "w-8 h-8 rounded-lg flex items-center justify-center hover:bg-red-500/10 text-red-500 active:scale-90 transition-all" },
                  React.createElement(Trash, { size: 15 })
                ),
                React.createElement('div', { className: "flex items-center gap-2" },
                  React.createElement('button', { onClick: function() { props.updateQty(r.id, -1); }, className: "w-7 h-7 rounded-lg bg-orange-500/15 flex items-center justify-center text-orange-600 dark:text-orange-400 active:scale-90 transition-all" },
                    React.createElement(Minus, { size: 13 })
                  ),
                  React.createElement('span', { className: "text-sm font-bold text-gray-900 dark:text-white w-4 text-center" }, r.qty),
                  React.createElement('button', { onClick: function() { props.updateQty(r.id, 1); }, className: "w-7 h-7 rounded-lg bg-orange-500/15 flex items-center justify-center text-orange-600 dark:text-orange-400 active:scale-90 transition-all" },
                    React.createElement(Plus, { size: 13 })
                  )
                )
              )
            );
          })
        ),

        React.createElement('div', { className: theme.card + " rounded-3xl p-5 mb-5" },
          React.createElement(SectionLabel, null, "Bill summary"),
          React.createElement('div', { className: "flex justify-between py-1.5" },
            React.createElement('span', { className: "text-sm text-gray-600 dark:text-gray-400" }, "Subtotal"),
            React.createElement('span', { className: "text-sm font-semibold text-gray-900 dark:text-white" }, "₹" + subtotal)
          ),
          React.createElement('div', { className: "flex justify-between py-1.5" },
            React.createElement('span', { className: "text-sm text-gray-600 dark:text-gray-400" }, "Delivery"),
            React.createElement('span', { className: delivery === 0 ? "text-sm font-semibold text-emerald-600 dark:text-emerald-400" : "text-sm font-semibold text-gray-900 dark:text-white" }, delivery === 0 ? "FREE" : "₹" + delivery)
          ),
          React.createElement('div', { className: "h-px my-2 bg-orange-100 dark:bg-gray-800" }),
          React.createElement('div', { className: "flex justify-between items-center" },
            React.createElement('span', { className: "text-sm font-bold text-gray-900 dark:text-white" }, "Total payable"),
            React.createElement('span', { className: "text-2xl font-black tracking-tight text-orange-600 dark:text-orange-400" }, "₹" + React.createElement(CountUp, { to: total }))
          )
        ),

        React.createElement('a', { href: buildWaLink(props.waNumber, orderText), target: "_blank", rel: "noreferrer", className: "w-full rounded-xl py-4 font-bold flex items-center justify-center gap-2 text-white shadow-lg active:scale-[0.98] transition-all", style: { backgroundColor: WA_GREEN, boxShadow: "0 8px 20px rgba(37,211,102,0.25)" } },
          React.createElement(MessageCircle, { size: 18 }), " Order on WhatsApp"
        ),
        React.createElement('button', { onClick: function() { props.placeOrder(rows, total); }, className: theme.card + " w-full rounded-xl py-3.5 font-semibold mt-3 text-gray-900 dark:text-white active:scale-[0.98] transition-all" }, "Place order in app · Cash on delivery")
      )
    )
  );
}

function OrdersPage(props) {
  var orders = props.orders || [];
  var statusStyle = function(s) {
    if (s === "Delivered") return "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400";
    if (s === "Cancelled") return "bg-red-500/15 text-red-600 dark:text-red-400";
    if (s === "Out for delivery") return "bg-orange-500/15 text-orange-600 dark:text-orange-400";
    return "bg-blue-500/15 text-blue-600 dark:text-blue-400";
  };
  return React.createElement(React.Fragment, null,
    React.createElement('div', { className: "min-h-screen" },
      React.createElement('div', { className: "px-5 pt-6 pb-24" },
        React.createElement('h2', { className: "text-2xl font-bold tracking-tight bg-gradient-to-r from-orange-500 to-purple-400 bg-clip-text text-transparent mb-4" }, "My Orders"),
        React.createElement('div', { className: theme.card + " rounded-2xl p-5 mb-5" },
          React.createElement(SectionLabel, null, "Order summary"),
          React.createElement('div', { className: "grid grid-cols-3" },
            React.createElement('div', { className: "flex flex-col  border-r border-orange-100 dark:border-gray-800" },
              React.createElement(Package, { size: 16, className: "text-orange-600 dark:text-orange-400" }),
              React.createElement('div', { className: "text-3xl font-black tracking-tight text-gray-900 dark:text-white mt-1" }, React.createElement(CountUp, { to: orders.length })),
              React.createElement('div', { className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "Total")
            ),
            React.createElement('div', { className: "flex flex-col  border-r border-orange-100 dark:border-gray-800" },
              React.createElement(Check, { size: 16, className: "text-orange-600 dark:text-orange-400" }),
              React.createElement('div', { className: "text-3xl font-black tracking-tight text-gray-900 dark:text-white mt-1" }, React.createElement(CountUp, { to: orders.filter(function(o) { return o.status === "Delivered"; }).length })),
              React.createElement('div', { className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "Delivered")
            ),
            React.createElement('div', { className: "flex flex-col " },
              React.createElement(Zap, { size: 16, className: "text-orange-600 dark:text-orange-400" }),
              React.createElement('div', { className: "text-3xl font-black tracking-tight text-gray-900 dark:text-white mt-1" }, React.createElement(CountUp, { to: orders.filter(function(o) { return o.status !== "Delivered" && o.status !== "Cancelled"; }).length })),
              React.createElement('div', { className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "In transit")
            )
          )
        ),
        React.createElement(SectionLabel, null, "Recent orders"),
        orders.length === 0 ? (
          React.createElement('div', { className: "text-center py-16 px-6" },
            React.createElement('div', { className: "text-6xl mb-4" }, "📦"),
            React.createElement('h3', { className: "text-lg font-bold mb-2 text-gray-900 dark:text-white" }, "No orders yet"),
            React.createElement('p', { className: "text-sm mb-6 text-gray-400 dark:text-gray-500" }, "Your first ApnaCart order will appear here."),
            React.createElement('button', { onClick: function() { props.setPage("home"); }, className: theme.btn + " " + theme.btnText + " px-6 py-3 rounded-xl font-semibold active:scale-95 transition-all" }, "Shop now")
          )
        ) : (
          React.createElement('div', { className: "space-y-2" },
            orders.map(function(o, i) {
              return React.createElement('div', { key: o.id, className: theme.card + " rounded-2xl p-4 w-full animate-fade-in-up", style: { animationDelay: (i * 70) + "ms" } },
                React.createElement('div', { className: "flex items-center justify-between" },
                  React.createElement('span', { className: "text-[11px] font-bold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "#" + o.id + " · " + o.date),
                  React.createElement('span', { className: "text-[10px] font-bold px-2 py-1 rounded-full " + statusStyle(o.status) }, o.status)
                ),
                React.createElement('p', { className: "text-sm font-semibold text-gray-900 dark:text-white mt-2" }, o.items),
                React.createElement('div', { className: "flex items-center justify-between mt-3 pt-3 border-t border-orange-100 dark:border-gray-800" },
                  React.createElement('span', { className: "text-lg font-black text-orange-600 dark:text-orange-400" }, "₹" + o.total),
                  React.createElement('button', { onClick: function() { toast({ title: "Reordered", description: "Items added back to your cart" }); }, className: "text-[11px] font-semibold text-orange-600 dark:text-orange-400 flex items-center gap-1 active:scale-95 transition-all" },
                    React.createElement(RefreshCw, { size: 12 }), " Order again"
                  )
                )
              );
            })
          )
        )
      )
    )
  );
}

function ProfilePage(props) {
  var ns = React.useState(props.waNumber);
  var num = ns[0];
  var setNum = ns[1];
  return React.createElement(React.Fragment, null,
    React.createElement('div', { className: "min-h-screen" },
      React.createElement('div', { className: "px-5 pt-6 pb-24" },
        React.createElement('h2', { className: "text-2xl font-bold tracking-tight bg-gradient-to-r from-orange-500 to-purple-400 bg-clip-text text-transparent mb-4" }, "Profile"),
        React.createElement('div', { className: theme.card + " rounded-3xl p-5" },
          React.createElement('div', { className: "flex items-center gap-4" },
            React.createElement('img', { src: "https://api.dicebear.com/7.x/avataaars/svg?seed=Aarav", alt: "Aarav", className: "w-16 h-16 rounded-full bg-orange-100 dark:bg-gray-800" }),
            React.createElement('div', { className: "flex-1 min-w-0" },
              React.createElement('p', { className: "text-lg font-semibold text-gray-900 dark:text-white" }, "Aarav Mehta"),
              React.createElement('p', { className: "text-[11px] text-gray-400 dark:text-gray-500" }, "aarav.mehta@gmail.com"),
              React.createElement(Badge, { className: "bg-orange-500/15 text-orange-600 dark:text-orange-400 border-0 text-[10px] font-bold mt-1" }, "Gold Member")
            )
          ),
          React.createElement('div', { className: "grid grid-cols-3 mt-5 pt-4 border-t border-orange-100 dark:border-gray-800" },
            React.createElement('div', { className: "flex flex-col  border-r border-orange-100 dark:border-gray-800" },
              React.createElement('span', { className: "text-2xl font-black text-gray-900 dark:text-white" }, React.createElement(CountUp, { to: 24 })),
              React.createElement('span', { className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "Orders")
            ),
            React.createElement('div', { className: "flex flex-col  border-r border-orange-100 dark:border-gray-800" },
              React.createElement('span', { className: "text-2xl font-black text-gray-900 dark:text-white" }, React.createElement(CountUp, { to: 8 })),
              React.createElement('span', { className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "Coupons")
            ),
            React.createElement('div', { className: "flex flex-col " },
              React.createElement('span', { className: "text-2xl font-black text-gray-900 dark:text-white" }, "₹" + React.createElement(CountUp, { to: 4820 })),
              React.createElement('span', { className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "Saved")
            )
          )
        ),

        React.createElement('div', { className: "grid grid-cols-2 gap-3 mt-4" },
          React.createElement('button', { onClick: function() { props.setPage("seller"); }, className: "rounded-2xl p-4 bg-gradient-to-br from-orange-500 to-rose-500 shadow-lg shadow-orange-500/25 text-left active:scale-95 transition-all" },
            React.createElement(Wallet, { size: 20, className: "text-white" }),
            React.createElement('p', { className: "text-sm font-bold text-white mt-2" }, "Seller Dashboard"),
            React.createElement('p', { className: "text-[10px] text-white/80" }, "Manage products & stock")
          ),
          React.createElement('button', { onClick: function() { props.setPage("orders"); }, className: theme.card + " rounded-2xl p-4 text-left active:scale-95 transition-all" },
            React.createElement(Package, { size: 20, className: "text-orange-600 dark:text-orange-400" }),
            React.createElement('p', { className: "text-sm font-bold text-gray-900 dark:text-white mt-2" }, "Track Orders"),
            React.createElement('p', { className: "text-[10px] text-gray-400 dark:text-gray-500" }, props.orders.length + " orders placed")
          )
        ),

        React.createElement('div', { className: "mt-5" },
          React.createElement(SectionLabel, null, "Seller WhatsApp number"),
          React.createElement('div', { className: theme.card + " rounded-2xl p-4" },
            React.createElement('label', { className: "text-[11px] font-semibold text-gray-600 dark:text-gray-400 block mb-1.5" }, "Your WhatsApp number (with country code)"),
            React.createElement('input', { value: num, onChange: function(e) { setNum(e.target.value.replace(/[^0-9]/g, "")); }, placeholder: "919999999999", className: theme.input }),
            React.createElement('p', { className: "text-[10px] text-gray-400 dark:text-gray-500 mt-1.5" }, "All customer orders will be sent to this number on WhatsApp."),
            React.createElement('button', { onClick: function() { props.setWaNumber(num); toast({ title: "Saved", description: "WhatsApp number updated to +" + num }); }, className: theme.btn + " " + theme.btnText + " w-full rounded-xl py-3 font-semibold mt-3 active:scale-95 transition-all" }, "Save number")
          )
        ),

        React.createElement('div', { className: "mt-5" },
          React.createElement(SectionLabel, null, "Preferences"),
          React.createElement('div', { className: theme.card + " rounded-2xl overflow-hidden divide-y divide-orange-100 dark:divide-gray-800" },
            React.createElement('div', { className: "flex items-center gap-3 p-4 w-full" },
              React.createElement('div', { className: "w-10 h-10 rounded-xl bg-orange-500/15 flex items-center justify-center shrink-0" },
                React.createElement(Moon, { size: 18, className: "text-orange-600 dark:text-orange-400" })
              ),
              React.createElement('div', { className: "flex-1 min-w-0" },
                React.createElement('p', { className: "text-sm font-semibold text-gray-900 dark:text-white" }, "Dark mode"),
                React.createElement('p', { className: "text-[11px] text-gray-400 dark:text-gray-500" }, "Easy on eyes at night")
              ),
              React.createElement('button', { onClick: function() { props.setDarkMode(!props.darkMode); toast({ title: props.darkMode ? "Light mode on" : "Dark mode on" }); }, className: "w-12 h-6 rounded-full transition-all shrink-0 " + (props.darkMode ? "bg-orange-500" : "bg-gray-300 dark:bg-gray-700") },
                React.createElement('div', { className: "w-5 h-5 rounded-full bg-white shadow transition-transform " + (props.darkMode ? "translate-x-6" : "translate-x-0.5") })
              )
            ),
            React.createElement('div', { className: "flex items-center gap-3 p-4 w-full" },
              React.createElement('div', { className: "w-10 h-10 rounded-xl bg-orange-500/15 flex items-center justify-center shrink-0" },
                React.createElement(Bell, { size: 18, className: "text-orange-600 dark:text-orange-400" })
              ),
              React.createElement('div', { className: "flex-1 min-w-0" },
                React.createElement('p', { className: "text-sm font-semibold text-gray-900 dark:text-white" }, "Order updates"),
                React.createElement('p', { className: "text-[11px] text-gray-400 dark:text-gray-500" }, "WhatsApp and push alerts")
              ),
              React.createElement('button', { onClick: function() { toast({ title: "Updated", description: "Notification setting changed" }); }, className: "w-12 h-6 rounded-full bg-orange-500 transition-all shrink-0" },
                React.createElement('div', { className: "w-5 h-5 rounded-full bg-white shadow translate-x-6" })
              )
            ),
            React.createElement('button', { onClick: function() { toast({ title: "Help", description: "Call +91 98765 43210" }); }, className: "flex items-center gap-3 p-4 w-full text-left" },
              React.createElement('div', { className: "w-10 h-10 rounded-xl bg-orange-500/15 flex items-center justify-center shrink-0" },
                React.createElement(HelpCircle, { size: 18, className: "text-orange-600 dark:text-orange-400" })
              ),
              React.createElement('div', { className: "flex-1 min-w-0" },
                React.createElement('p', { className: "text-sm font-semibold text-gray-900 dark:text-white" }, "Help & support"),
                React.createElement('p', { className: "text-[11px] text-gray-400 dark:text-gray-500" }, "We reply within 10 minutes")
              ),
              React.createElement(ChevronRight, { size: 16, className: "text-gray-400 dark:text-gray-500 shrink-0" })
            ),
            React.createElement('button', { onClick: function() { toast({ title: "Share", description: "ApnaCart link copied" }); }, className: "flex items-center gap-3 p-4 w-full text-left" },
              React.createElement('div', { className: "w-10 h-10 rounded-xl bg-orange-500/15 flex items-center justify-center shrink-0" },
                React.createElement(Share, { size: 18, className: "text-orange-600 dark:text-orange-400" })
              ),
              React.createElement('div', { className: "flex-1 min-w-0" },
                React.createElement('p', { className: "text-sm font-semibold text-gray-900 dark:text-white" }, "Share ApnaCart"),
                React.createElement('p', { className: "text-[11px] text-gray-400 dark:text-gray-500" }, "Invite friends, get ₹100 off")
              ),
              React.createElement(ChevronRight, { size: 16, className: "text-gray-400 dark:text-gray-500 shrink-0" })
            )
          )
        )
      )
    )
  );
}

function SellerPage(props) {
  var products = props.products || [];
  var live = products.filter(function(p) { return p.published; });
  var stockValue = products.reduce(function(s, p) { return s + (p.price * p.stock); }, 0);
  var lowStock = products.filter(function(p) { return p.stock < 10; });
  var orders = props.orders || [];
  var revenue = orders.reduce(function(s, o) { return s + o.total; }, 0);
  return React.createElement(React.Fragment, null,
    React.createElement('div', { className: "min-h-screen" },
      React.createElement('div', { className: "px-5 pt-6 pb-24" },
        React.createElement('div', { className: "flex items-center gap-3 mb-4" },
          React.createElement('button', { onClick: function() { props.setPage("profile"); }, className: "w-9 h-9 rounded-xl bg-orange-500/15 flex items-center justify-center text-orange-600 dark:text-orange-400 active:scale-90 transition-all" },
            React.createElement(ArrowLeft, { size: 16 })
          ),
          React.createElement('h2', { className: "text-2xl font-bold tracking-tight bg-gradient-to-r from-orange-500 to-purple-400 bg-clip-text text-transparent" }, "Seller Dashboard")
        ),

        React.createElement('div', { className: "rounded-3xl bg-gradient-to-br from-orange-500 to-rose-500 p-5 shadow-lg shadow-orange-500/25" },
          React.createElement('p', { className: "text-[11px] font-semibold uppercase tracking-[0.12em] text-white/80" }, "Total revenue"),
          React.createElement('p', { className: "text-4xl font-black tracking-tight text-white mt-1" }, "₹" + React.createElement(CountUp, { to: revenue })),
          React.createElement('div', { className: "flex items-center gap-2 mt-2" },
            React.createElement(TrendingUp, { size: 14, className: "text-white" }),
            React.createElement('span', { className: "text-[11px] font-semibold text-white/90" }, "+18% vs last week")
          )
        ),

        React.createElement('div', { className: "grid grid-cols-3 gap-3 mt-4" },
          React.createElement('div', { className: theme.card + " rounded-2xl p-3" },
            React.createElement(ShoppingBag, { size: 16, className: "text-orange-600 dark:text-orange-400" }),
            React.createElement('p', { className: "text-xl font-black text-gray-900 dark:text-white mt-1" }, React.createElement(CountUp, { to: products.length })),
            React.createElement('p', { className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "Products")
          ),
          React.createElement('div', { className: theme.card + " rounded-2xl p-3" },
            React.createElement(Check, { size: 16, className: "text-orange-600 dark:text-orange-400" }),
            React.createElement('p', { className: "text-xl font-black text-gray-900 dark:text-white mt-1" }, React.createElement(CountUp, { to: live.length })),
            React.createElement('p', { className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "Published")
          ),
          React.createElement('div', { className: theme.card + " rounded-2xl p-3" },
            React.createElement(AlertCircle, { size: 16, className: "text-orange-600 dark:text-orange-400" }),
            React.createElement('p', { className: "text-xl font-black text-gray-900 dark:text-white mt-1" }, React.createElement(CountUp, { to: lowStock.length })),
            React.createElement('p', { className: "text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" }, "Low stock")
          )
        ),

        React.createElement('div', { className: theme.card + " rounded-3xl p-5 mt-4" },
          React.createElement(SectionLabel, null, "Weekly orders"),
          React.createElement(MiniBarChart, { values: [12, 19, 8, 25, 17, 22, 14], color: "bg-orange-500", height: 70 }),
          React.createElement('div', { className: "flex justify-between mt-2 text-[10px] font-semibold uppercase tracking-wider text-gray-400 dark:text-gray-500" },
            React.createElement('span', null, "Mon"),
            React.createElement('span', null, "Tue"),
            React.createElement('span', null, "Wed"),
            React.createElement('span', null, "Thu"),
            React.createElement('span', null, "Fri"),
            React.createElement('span', null, "Sat"),
            React.createElement('span', null, "Sun")
          )
        ),

        React.createElement('div', { className: "grid grid-cols-2 gap-3 mt-4" },
          React.createElement('div', { className: theme.card + " rounded-2xl p-4" },
            React.createElement(SectionLabel, null, "Stock value"),
            React.createElement('p', { className: "text-xl font-black text-gray-900 dark:text-white" }, "₹" + React.createElement(CountUp, { to: stockValue })),
            React.createElement('p', { className: "text-[10px] text-gray-400 dark:text-gray-500 mt-0.5" }, "Across " + products.length + " SKUs")
          ),
          React.createElement('div', { className: theme.card + " rounded-2xl p-4" },
            React.createElement(SectionLabel, null, "Avg rating"),
            React.createElement('p', { className: "text-xl font-black text-gray-900 dark:text-white" }, "4.5 ★"),
            React.createElement('p', { className: "text-[10px] text-gray-400 dark:text-gray-500 mt-0.5" }, "From 1,499 buyers")
          )
        ),

        lowStock.length > 0 ? (
          React.createElement('div', { className: "mt-5" },
            React.createElement(SectionLabel, null, "Restock alerts"),
            React.createElement('div', { className: "space-y-2" },
              lowStock.map(function(p, i) {
                return React.createElement('div', { key: p.id, className: theme.card + " rounded-2xl p-3 flex items-center gap-3 w-full animate-fade-in-up", style: { animationDelay: (i * 70) + "ms" } },
                  React.createElement('img', { src: p.image, alt: p.name, className: "w-12 h-12 rounded-xl object-cover shrink-0" }),
                  React.createElement('div', { className: "flex-1 min-w-0" },
                    React.createElement('p', { className: "text-sm font-bold truncate " + theme.cardHeading }, p.name),
                    React.createElement('p', { className: "text-[11px] text-amber-600 dark:text-amber-400" }, p.stock === 0 ? "Out of stock" : "Only " + p.stock + " left")
                  ),
                  React.createElement('button', { onClick: function() { props.onEdit(p); }, className: "shrink-0 px-3 py-1.5 rounded-lg bg-orange-500/15 text-orange-600 dark:text-orange-400 text-[11px] font-semibold active:scale-95 transition-all" }, "Restock")
                );
              })
            )
          )
        ) : null,

        React.createElement('div', { className: "flex items-center justify-between mt-6 mb-2" },
          React.createElement(SectionLabel, null, "Manage products"),
          React.createElement('button', { onClick: function() { props.onEdit(null); }, className: theme.btn + " " + theme.btnText + " px-3 py-1.5 rounded-lg text-[11px] font-semibold flex items-center gap-1 active:scale-95 transition-all" },
            React.createElement(Plus, { size: 12 }), " Add product"
          )
        ),
        React.createElement('div', { className: "space-y-2" },
          products.map(function(p, i) {
            return React.createElement('div', { key: p.id, className: theme.card + " rounded-2xl p-3 flex items-center gap-3 w-full animate-fade-in-up", style: { animationDelay: (i * 50) + "ms" } },
              React.createElement('img', { src: p.image, alt: p.name, className: "w-12 h-12 rounded-xl object-cover shrink-0" }),
              React.createElement('div', { className: "flex-1 min-w-0" },
                React.createElement('p', { className: "text-sm font-bold truncate " + theme.cardHeading }, p.name),
                React.createElement('p', { className: "text-[11px] truncate " + theme.cardSubtle }, p.category + " · ₹" + p.price + " · Stock " + p.stock),
                React.createElement('span', { className: "text-[10px] font-bold " + (p.published ? "text-emerald-600 dark:text-emerald-400" : "text-gray-400 dark:text-gray-500") }, p.published ? "● Live on store" : "○ Draft")
              ),
              React.createElement('div', { className: "flex items-center gap-1 shrink-0" },
                React.createElement('button', { onClick: function() { props.togglePublish(p.id); }, className: "w-8 h-8 rounded-lg flex items-center justify-center hover:bg-orange-500/10 text-orange-600 dark:text-orange-400 active:scale-90 transition-all" },
                  React.createElement(Eye, { size: 15 })
                ),
                React.createElement('button', { onClick: function() { props.onEdit(p); }, className: "w-8 h-8 rounded-lg flex items-center justify-center hover:bg-orange-500/10 text-orange-600 dark:text-orange-400 active:scale-90 transition-all" },
                  React.createElement(Edit, { size: 15 })
                ),
                React.createElement('button', { onClick: function() { props.removeProduct(p.id); }, className: "w-8 h-8 rounded-lg flex items-center justify-center hover:bg-red-500/10 text-red-500 active:scale-90 transition-all" },
                  React.createElement(Trash, { size: 15 })
                )
              )
            );
          })
        )
      )
    )
  );
}

function BottomNav(props) {
  var items = [
    { id: 'home', icon: React.createElement(Home, { size: 20 }) },
    { id: 'search', icon: React.createElement(Search, { size: 20 }) },
    { id: 'cart', icon: React.createElement(ShoppingCart, { size: 20 }) },
    { id: 'orders', icon: React.createElement(Package, { size: 20 }) },
    { id: 'profile', icon: React.createElement(User, { size: 20 }) }
  ];
  return React.createElement('div', { className: "fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-orange-100 dark:border-gray-800 flex justify-around py-2" },
    items.map(function(t) {
      return React.createElement('button', { key: t.id, onClick: function() { props.setPage(t.id); }, className: cn("flex flex-col items-center gap-0.5 px-3 py-1 rounded-xl", props.page === t.id ? "text-orange-600" : "text-gray-400") }, t.icon);
    })
  );
}

function App() {
  var ps = React.useState('home');
  var page = ps[0];
  var setPage = ps[1];

  var productsState = useZapplyDB('products', SEED_PRODUCTS);
  var products = productsState[0];
  var setProducts = productsState[1];

  var cartState = useZapplyDB('cart', []);
  var cart = cartState[0];
  var setCart = cartState[1];

  var ordersState = useZapplyDB('orders', SEED_ORDERS);
  var orders = ordersState[0];
  var setOrders = ordersState[1];

  var waState = useZapplyDB('waNumber', '919876543210');
  var waNumber = waState[0];
  var setWaNumber = waState[1];

  var darkState = useZapplyDB('darkMode', false);
  var darkMode = darkState[0];
  var setDarkMode = darkState[1];

  var catState = React.useState('All');
  var category = catState[0];
  var setCategory = catState[1];

  var prodState = React.useState(null);
  var selectedProduct = prodState[0];
  var setSelectedProduct = prodState[1];

  React.useEffect(function() {
    if (darkMode) document.body.classList.add('dark');
    else document.body.classList.remove('dark');
  }, [darkMode]);

  function onAdd(p) {
    setCart(function(prev) {
      var existing = prev.find(function(c) { return c.id === p.id; });
      if (existing) return prev.map(function(c) { return c.id === p.id ? Object.assign({}, c, {qty: c.qty + 1}) : c; });
      return [].concat(prev, [{ id: p.id, qty: 1 }]);
    });
    toast({ title: 'Added', description: p.name + ' added to cart' });
  }

  function onAddQty(p, qty) {
    setCart(function(prev) {
      var existing = prev.find(function(c) { return c.id === p.id; });
      if (existing) return prev.map(function(c) { return c.id === p.id ? { ...c, qty } : c; });
      return [].concat(prev, [{ id: p.id, qty }]);
    });
  }

  function updateQty(id, delta) {
    setCart(function(prev) {
      return prev.map(function(c) {
        return c.id === id ? Object.assign({}, c, {qty: Math.max(1, c.qty + delta)}) : c;
      });
    });
  }

  function removeFromCart(id) {
    setCart(function(prev) { return prev.filter(function(c) { return c.id !== id; }); });
  }

  function placeOrder(rows, total) {
    var newOrder = {
      id: 'AC' + Math.floor(10000 + Math.random() * 90000),
      date: new Date().toISOString().slice(0, 10),
      status: 'Processing',
      total: total,
      items: rows.map(function(r) { return r.product.name + ' x' + r.qty; }).join(', ')
    };
    setOrders(function(prev) { return [newOrder, ...prev]; });
    setCart([]);
    toast({ title: 'Order placed', description: 'Order #' + newOrder.id + ' placed' });
  }

  function onOpen(p) {
    setSelectedProduct(p);
    setPage('product');
  }

  function onEdit(p) {
    setSelectedProduct(p);
    // For simplicity, reuse SellerPage with edit capability via prop
    // In a full app, would open a separate edit page
  }

  function togglePublish(id) {
    setProducts(function(prev) {
      return prev.map(function(p) {
        return p.id === id ? Object.assign({}, p, {published: !p.published}) : p;
      });
    });
  }

  function removeProduct(id) {
    setProducts(function(prev) { return prev.filter(function(p) { return p.id !== id; }); });
  }

  function addProduct(newProduct) {
    setProducts(function(prev) {
      return [].concat(prev, [Object.assign({}, newProduct, {id: Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7)})]);
    });
  }

  function updateProduct(id, updates) {
    setProducts(function(prev) {
      return prev.map(function(p) {
        return p.id === id ? { ...p, ...updates } : p;
      });
    });
  }

  var renderPage = function() {
    switch (page) {
      case 'home':
        return React.createElement(HomePage, {
          products: products,
          cart: cart,
          onAdd: onAdd,
          onOpen: onOpen,
          setPage: setPage,
          setCategory: setCategory
        });
      case 'search':
        return React.createElement(SearchPage, {
          products: products,
          onAdd: onAdd,
          onOpen: onOpen,
          category: category,
          setCategory: setCategory,
          setPage: setPage
        });
      case 'product':
        return React.createElement(DetailPage, {
          product: selectedProduct,
          products: products,
          onAdd: onAdd,
          onAddQty: onAddQty,
          setPage: setPage,
          waNumber: waNumber
        });
      case 'cart':
        return React.createElement(CartPage, {
          cart: cart,
          products: products,
          onAdd: onAdd,
          updateQty: updateQty,
          removeFromCart: removeFromCart,
          placeOrder: placeOrder,
          setPage: setPage,
          waNumber: waNumber
        });
      case 'orders':
        return React.createElement(OrdersPage, {
          orders: orders,
          setPage: setPage
        });
      case 'profile':
        return React.createElement(ProfilePage, {
          orders: orders,
          waNumber: waNumber,
          setWaNumber: setWaNumber,
          darkMode: darkMode,
          setDarkMode: setDarkMode,
          setPage: setPage
        });
      case 'seller':
        return React.createElement(SellerPage, {
          products: products,
          orders: orders,
          onEdit: onEdit,
          togglePublish: togglePublish,
          removeProduct: removeProduct,
          addProduct: addProduct,
          updateProduct: updateProduct,
          setPage: setPage
        });
      default:
        return React.createElement(HomePage, {
          products: products,
          cart: cart,
          onAdd: onAdd,
          onOpen: onOpen,
          setPage: setPage,
          setCategory: setCategory
        });
    }
  };

  return React.createElement('div', { className: theme.bg + " min-h-screen" },
    renderPage(),
    React.createElement(BottomNav, { page: page, setPage: setPage })
  );
}